<?php
/**
 * Plugin Name: YOO CCC Reading Time
 * Plugin URI: https://coolcat-creations.com
 * Description: YOOtheme Pro Element to display the reading time of a block or specific content
 * Author: Elisa Sophia Foltyn
 * Version: 0.0.1
 * Author URI: https://coolcat-creations.com
 * License: GNU General Public License
 * Text Domain: yoocccreadingtime
 * Update URI: https://coolcat-campus.com/updates/update.json
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit();

use YOOtheme\Application;

add_action('after_setup_theme', function () {
    // Check if the YOOtheme app class exists
    if (!class_exists(Application::class, false)) {
        return;
    }

    // Load module from the same directory
    $app = Application::getInstance();
    $app->load(__DIR__ . '/modules/*/bootstrap.php');
});

add_filter('update_plugins_coolcat-campus.com', function($update, $plugin_data, $plugin_file, $locales) {
    if ($plugin_file == plugin_basename(__FILE__)) {
		$request = wp_remote_get($plugin_data['UpdateURI']);
		$request_body = wp_remote_retrieve_body( $request );
		$update = json_decode( $request_body, true );
	}

	return $update;
},10, 4);
